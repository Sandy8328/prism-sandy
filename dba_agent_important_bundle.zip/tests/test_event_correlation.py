"""Regression tests for evidence-first event extraction and ORA role assignment."""

from src.agent.event_correlation import (
    build_event_correlation_analysis,
    extract_events,
)


def test_extract_events_finds_ora_and_trace():
    text = """
2024-03-16T07:30:00+00:00 Errors in file /u01/app/oracle/diag/rdbms/prd/prd/trace/prd_lgwr_123.trc:
ORA-00353: log corruption near block 1
ORA-00312: online log 3 thread 1: '/redo03.log'
""".strip()
    ev = extract_events(text)
    assert any("ORA-00353" in (e.get("oracle_codes") or []) for e in ev)
    assert any("prd_lgwr_123.trc" in (e.get("trace_file") or "") for e in ev)


def test_ora_27072_role_db_io_symptom():
    text = "Mar 16 07:31:01 db01 kernel: qla2xxx: Adapter reset issued\nORA-27072: Linux Error: 5: Input/output error\n"
    parsed = {
        "raw_input": text,
        "all_ora_codes": ["ORA-27072"],
        "primary_ora": "ORA-27072",
        "hostname": "db01",
        "observed_layers": ["DB", "OS"],
        "direct_pattern_ids": ["FC_HBA_RESET"],
        "mode": "log_paste",
    }
    rca = build_event_correlation_analysis(parsed, [], None, {"pattern_id": "FC_HBA_RESET", "score": 90})
    rows = {r["error"]: r["role"] for r in rca["correlated_error_table"]}
    assert rows["ORA-27072"] == "DB_IO_SYMPTOM"


def test_storage_signal_prefers_storage_root_label():
    text = """
FLASH_IO_TIMEOUT warningCode=FLASH_IO_TIMEOUT flashDisk=FD_02
ORA-15080: synchronous I/O operation failed
""".strip()
    parsed = {
        "raw_input": text,
        "all_ora_codes": ["ORA-15080"],
        "primary_ora": "ORA-15080",
        "hostname": "",
        "observed_layers": ["STORAGE", "DB"],
        "direct_pattern_ids": ["EXA_FLASH_FAIL"],
        "mode": "log_paste",
    }
    rca = build_event_correlation_analysis(
        parsed,
        [],
        {"root_pattern": "EXA_FLASH_FAIL", "causal_chain": ["ROOT: EXA_FLASH_FAIL", "DB: ORA-15080"]},
        {"pattern_id": "EXA_FLASH_FAIL", "score": 90},
    )
    assert "STORAGE" in rca["root_cause_candidate"]["root_cause"].upper() or "FLASH" in rca["root_cause_candidate"]["root_cause"].upper()


def test_annotate_fix_marks_destructive():
    from src.agent.event_correlation import annotate_fix_command_categories

    fixes = [
        {
            "fix_id": "x",
            "commands": ["alter database recover database until cancel"],
            "risk": "HIGH",
            "requires": "dba",
            "downtime_required": True,
        }
    ]
    out = annotate_fix_command_categories(fixes)
    assert out[0]["command_category"] == "DESTRUCTIVE_DBA_APPROVAL_REQUIRED"


def test_multipath_bundle_is_diagnostic():
    from src.agent.event_correlation import annotate_fix_command_categories

    fixes = [
        {
            "fix_id": "checks",
            "commands": ["multipath -ll", "dmesg -T | tail -50"],
            "risk": "LOW",
            "requires": "root",
            "downtime_required": False,
        }
    ]
    out = annotate_fix_command_categories(fixes)
    assert out[0]["command_category"] == "DIAGNOSTIC"


def test_non_ora_table_separate_from_ora_table():
    text = "ORA-00353: corruption\nLGWR terminating the instance due to error 353\n"
    parsed = {
        "raw_input": text,
        "all_ora_codes": ["ORA-00353"],
        "primary_ora": "ORA-00353",
        "hostname": "",
        "observed_layers": ["DB"],
        "direct_pattern_ids": [],
        "mode": "log_paste",
    }
    rca = build_event_correlation_analysis(parsed, [], None, None)
    ora_codes_in_ora_tbl = {r["error"] for r in rca["observed_ora_correlation_table"]}
    assert "ORA-00353" in ora_codes_in_ora_tbl
    events_non_ora = {r.get("event") for r in rca["non_ora_correlated_events"]}
    assert "LGWR_INSTANCE_TERMINATION" in events_non_ora
    assert "LGWR_INSTANCE_TERMINATION" not in ora_codes_in_ora_tbl


def test_os_path_patterns_root_not_ora_27072_when_asm_present():
    """DB+ASM+OS without cell/storage: deepest root is OS path, not ORA-27072."""
    text = """
2024-03-16T08:00:01+00:00 kernel: scsi 0:0:1:2: SCSI_DISK_TIMEOUT on /dev/sdb
2024-03-16T08:00:02+00:00 multipathd: mpath4: all paths down
2024-03-16T08:00:03+00:00 +DATA ORA-15080: synchronous I/O operation failed for disk /dev/mpath4
2024-03-16T08:00:04+00:00 ORA-15130: diskgroup +DATA dismounted
2024-03-16T08:00:05+00:00 Errors in file /u01/app/oracle/diag/rdbms/x/x/trace/x_lgwr_1.trc:
ORA-27072: file I/O error; Linux Error: 5 Input/output error
ORA-00353: log corruption near block 1
ORA-00312: online log 1 thread 1: '/redo01.log'
""".strip()
    parsed = {
        "raw_input": text,
        "all_ora_codes": [
            "ORA-15080",
            "ORA-15130",
            "ORA-27072",
            "ORA-00353",
            "ORA-00312",
        ],
        "primary_ora": "ORA-27072",
        "hostname": "db01",
        "observed_layers": ["OS", "ASM", "DB"],
        "direct_pattern_ids": ["SCSI_DISK_TIMEOUT", "MULTIPATH_ALL_PATHS_DOWN"],
        "mode": "log_paste",
    }
    rca = build_event_correlation_analysis(parsed, [], None, None)
    root = rca["root_cause_candidate"]["root_cause"]
    assert root != "ORA-27072"
    assert root == "OS_STORAGE_PATH_FAILURE"
    assert rca["root_cause_candidate"]["layer"] == "OS"
    cascade = "\n".join(rca["cascade_chain_marked"])
    assert "NEEDS_EVIDENCE" in cascade
    assert "MULTIPATH_ALL_PATHS_DOWN" in cascade
    assert "SCSI_DISK_TIMEOUT" in cascade
    assert "ORA-15080" in cascade and "ORA-27072" in cascade and "ORA-00353" in cascade
    # Bridge symptom after ASM ORAs, before redo fatals
    lines = rca["cascade_chain_marked"]
    idx_150 = next(i for i, s in enumerate(lines) if "ORA-15080" in s)
    idx_270 = next(i for i, s in enumerate(lines) if "ORA-27072" in s)
    idx_353 = next(i for i, s in enumerate(lines) if "ORA-00353" in s)
    assert idx_150 < idx_270 < idx_353


def test_pattern_desc_avoids_misleading_os_error_for_storage_root():
    from src.agent.report_builder import _get_pattern_desc

    s = _get_pattern_desc("STORAGE_FLASH_IO_OR_MEDIA_FAILURE")
    assert "os error pattern" not in s.lower()
    assert "storage" in s.lower()
