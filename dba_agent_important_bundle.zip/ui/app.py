"""
app.py — Streamlit UI for the Oracle DBA Diagnostic Agent.

Run: streamlit run ui/app.py
"""

from __future__ import annotations
import os
import sys
import time
import json
import zipfile
from collections import Counter
from datetime import datetime

# Project root (absolute; do not chdir — avoids breaking paths in multi-process runs)
_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

import streamlit as st
import yaml

# Load config for defaults
_ROOT_CFG = os.path.join(_ROOT, "config", "settings.yaml")
try:
    with open(_ROOT_CFG) as _cf:
        _cfg = yaml.safe_load(_cf)
    _DEFAULT_TOP_K    = _cfg.get("retrieval", {}).get("top_k", 10)
    _MODEL_NAME       = _cfg.get("embedding", {}).get("model_name", "all-MiniLM-L6-v2")
except Exception:
    _DEFAULT_TOP_K = 10
    _MODEL_NAME    = "all-MiniLM-L6-v2"

# ── Page config ─────────────────────────────────────────────────
st.set_page_config(
    page_title="Oracle DBA Diagnostic Agent",
    page_icon="🔍",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS ──────────────────────────────────────────────────────────
st.markdown("""
<style>
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');

  html, body, [class*="css"] { font-family: 'Inter', sans-serif; }

  .main { background: #0d1117; }
  .stApp { background: #0d1117; color: #e6edf3; }

  /* Title bar */
  .title-bar {
    background: linear-gradient(135deg, #1f2d3d 0%, #0d1b2e 100%);
    border: 1px solid #30363d;
    border-radius: 12px;
    padding: 20px 28px;
    margin-bottom: 24px;
  }
  .title-bar h1 { font-size: 24px; font-weight: 700; color: #58a6ff; margin: 0; }
  .title-bar p  { font-size: 13px; color: #8b949e; margin: 4px 0 0; }

  /* Confidence badge */
  .badge-high   { background:#1a4731; color:#3fb950; border:1px solid #238636;
                  border-radius:6px; padding:3px 10px; font-size:13px; font-weight:600; }
  .badge-medium { background:#3d2b00; color:#d29922; border:1px solid #9e6a03;
                  border-radius:6px; padding:3px 10px; font-size:13px; font-weight:600; }
  .badge-low    { background:#3d1c00; color:#f0883e; border:1px solid #bd561d;
                  border-radius:6px; padding:3px 10px; font-size:13px; font-weight:600; }
  .badge-nomatch{ background:#21262d; color:#6e7681; border:1px solid #30363d;
                  border-radius:6px; padding:3px 10px; font-size:13px; font-weight:600; }

  /* Cards */
  .card {
    background: #161b22;
    border: 1px solid #30363d;
    border-radius: 10px;
    padding: 16px 20px;
    margin-bottom: 14px;
  }
  .card-title { font-size:13px; font-weight:600; color:#8b949e; text-transform:uppercase;
                letter-spacing:0.5px; margin-bottom:10px; }

  /* Chain item */
  .chain-item { background:#1c2128; border-left:3px solid #58a6ff;
                border-radius:0 6px 6px 0; padding:6px 12px;
                margin:4px 0; font-size:13px; font-family:monospace; }
  .chain-root { border-left-color:#da3633; }
  .chain-db   { border-left-color:#f0883e; }

  /* Fix command */
  .fix-cmd { background:#0d1117; border:1px solid #30363d; border-radius:6px;
             padding:8px 12px; font-family:monospace; font-size:12px;
             color:#79c0ff; margin:4px 0; }

  /* Evidence box */
  .evidence-box { background:#0d1117; border:1px solid #21262d;
                  border-radius:6px; padding:10px 14px; margin:6px 0;
                  font-family:monospace; font-size:11px; color:#8b949e;
                  max-height:120px; overflow-y:auto; }

  /* Cascade banner */
  .cascade-banner {
    background: linear-gradient(135deg, #2d1b00 0%, #3d2400 100%);
    border: 1px solid #9e6a03;
    border-radius: 8px;
    padding: 12px 16px;
    margin-bottom: 14px;
  }

  /* Metric row */
  .metric-row { display:flex; gap:16px; flex-wrap:wrap; margin-bottom:14px; }
  .metric-box { background:#161b22; border:1px solid #30363d; border-radius:8px;
                padding:12px 16px; flex:1; min-width:120px; }
  .metric-val { font-size:22px; font-weight:700; color:#58a6ff; }
  .metric-lbl { font-size:11px; color:#8b949e; margin-top:2px; }

  /* Sidebar */
  section[data-testid="stSidebar"] {
    background: #161b22;
    border-right: 1px solid #30363d;
  }
</style>
""", unsafe_allow_html=True)


# ── Agent init (cached) ──────────────────────────────────────────
@st.cache_resource(show_spinner=False)
def load_agent():
    from src.agent.agent import get_agent
    return get_agent()


# ── Helpers ──────────────────────────────────────────────────────
def _badge(label: str) -> str:
    cls = {
        "HIGH": "badge-high",
        "MEDIUM": "badge-medium",
        "LOW": "badge-low",
    }.get(label, "badge-nomatch")
    return f'<span class="{cls}">{label}</span>'


def _render_causal_chain(chain: list[str]):
    for step in chain:
        cls = "chain-root" if step.startswith("ROOT") else "chain-db" if step.startswith("DB") else ""
        st.markdown(f'<div class="chain-item {cls}">{step}</div>', unsafe_allow_html=True)


def _render_fix(fix: dict, idx: int):
    risk_color = {"LOW":"#3fb950","MEDIUM":"#d29922","HIGH":"#f0883e","CRITICAL":"#da3633"}.get(fix["risk"],"#8b949e")
    dt = "⚠️ Downtime required" if fix.get("downtime_required") else ""
    cat = fix.get("command_category") or "REMEDIATION"
    cat_badge = f'<span style="color:#8b949e;font-size:11px">[{cat}]</span>'
    st.markdown(
        f'<div class="card">'
        f'<div class="card-title">Fix {fix["priority"]} — {fix["fix_id"]} '
        f'<span style="color:{risk_color}">●</span> {fix["risk"]} risk '
        f'<span style="color:#8b949e;font-size:11px">requires: {fix["requires"]}</span>'
        f" {cat_badge}"
        f'{" &nbsp;&nbsp; " + dt if dt else ""}</div>',
        unsafe_allow_html=True
    )
    for cmd in fix["commands"]:
        st.markdown(f'<div class="fix-cmd">$ {cmd}</div>', unsafe_allow_html=True)
    st.markdown("</div>", unsafe_allow_html=True)


def _append_incident_history(report: dict | None) -> None:
    """Record one row per completed diagnosis (not on every Streamlit rerun)."""
    if not report:
        return
    st.session_state["incident_history"].append({
        "time": time.strftime("%H:%M:%S"),
        "status": report.get("status"),
        "ora": (report.get("ora_code") or {}).get("code", ""),
        "pattern": (report.get("root_cause") or {}).get("pattern", ""),
    })


def _append_zip_bundle_to_incident_context(tag: str, filename: str, report: dict | None) -> None:
    """
    Persist a short text summary of ZIP bundle analysis so paste/file follow-up
    can correlate with the prior bundle (raw archive bytes are not kept in session).
    """
    if not report:
        return
    lines = [f"\n[{tag}] {filename}"]
    bs = report.get("bundle_summary") or {}
    if bs:
        parts = []
        if bs.get("analyzed_files") is not None:
            parts.append(f"analyzed_files={bs['analyzed_files']}")
        if bs.get("primary_file"):
            parts.append(f"primary_file={bs['primary_file']}")
        if bs.get("platform_inferred"):
            parts.append(f"platform={bs['platform_inferred']}")
        if parts:
            lines.append("bundle_summary: " + ", ".join(parts))
    rep_status = report.get("status")
    lines.append(f"status={rep_status}")
    if rep_status == "SUCCESS":
        ora = (report.get("ora_code") or {}).get("code", "")
        rc = (report.get("root_cause") or {}).get("pattern", "")
        if ora or rc:
            lines.append(f"finding: ora={ora} pattern={rc}")
    else:
        nmr = (report.get("no_match_reason") or "")[:800]
        if nmr:
            lines.append(f"no_match_reason: {nmr}")
    for row in (report.get("secondary_findings") or [])[:6]:
        lines.append(
            f"secondary: file={row.get('file')} st={row.get('status')} "
            f"ora={row.get('ora_code')} pat={row.get('pattern')}"
        )
    st.session_state["incident_context_text"] += "\n" + "\n".join(lines)


def _begin_new_incident_session() -> None:
    """
    Primary Diagnose actions should start a fresh incident context.
    Continue Investigation is the only path that intentionally accumulates.
    """
    st.session_state["incident_context_text"] = ""


def _parse_ts(ts: str) -> datetime | None:
    if not ts:
        return None
    # Keep parser local to avoid startup penalty when not needed.
    from dateutil import parser as dp
    try:
        return dp.parse(ts)
    except Exception:
        return None


def _evaluate_followup_relevance(
    incoming_text: str,
    last_report: dict | None,
    override_hostname: str,
    override_platform: str,
) -> tuple[bool, list[str]]:
    """
    Validate whether follow-up evidence appears related to the same incident.
    Uses ORA, hostname, platform, and timestamp proximity as guardrails.
    """
    from src.agent.input_parser import parse_input

    parsed = parse_input(incoming_text)
    reasons: list[str] = []

    base_ora = ((last_report or {}).get("ora_code") or {}).get("code", "")
    base_family = set(
        [x for x in [base_ora] + ((last_report or {}).get("related_errors") or []) if x]
    )
    new_family = set(parsed.get("all_ora_codes") or ([parsed.get("primary_ora")] if parsed.get("primary_ora") else []))
    # Accept follow-ups when there is ORA family overlap, even if primary ORA changed
    # (e.g. ORA-27072 -> ORA-15080 -> ORA-00353 in the same storage incident).
    if base_family and new_family and not (base_family & new_family):
        reasons.append(
            f"ORA mismatch: existing family `{', '.join(sorted(base_family))}` "
            f"vs follow-up `{', '.join(sorted(new_family))}`."
        )

    base_host = override_hostname or ((last_report or {}).get("hostname") or "")
    new_host = parsed.get("hostname", "")
    if base_host and new_host and base_host.lower() != new_host.lower():
        reasons.append(f"Hostname mismatch: existing `{base_host}` vs follow-up `{new_host}`.")

    base_platform = override_platform if override_platform and override_platform != "(auto-detect)" else ((last_report or {}).get("platform") or "")
    new_platform = parsed.get("platform", "")
    if (
        base_platform
        and new_platform
        and base_platform.upper() != "UNKNOWN"
        and new_platform.upper() != "UNKNOWN"
        and base_platform.upper() != new_platform.upper()
    ):
        reasons.append(f"Platform mismatch: existing `{base_platform}` vs follow-up `{new_platform}`.")

    base_ts = _parse_ts((last_report or {}).get("timestamp_str", ""))
    new_ts = _parse_ts(parsed.get("timestamp_str", ""))
    if base_ts and new_ts:
        if abs((new_ts - base_ts).total_seconds()) > (6 * 3600):
            reasons.append("Timestamp appears outside 6-hour incident window.")

    return (len(reasons) == 0), reasons


def _followup_ack(report: dict, prefix: str) -> str:
    conf = report.get("confidence") or {}
    score = conf.get("score", 0)
    reason = report.get("no_match_reason") or "Evidence accepted for correlation."
    bd = conf.get("breakdown") or {}
    why = (
        f"keyword={bd.get('keyword',0)}, bm25={bd.get('bm25',0)}, "
        f"semantic={bd.get('dense',0)}, temporal={bd.get('temporal',0)}"
    )
    return (
        f"{prefix} — **{report.get('status')}** "
        f"(confidence: **{score}%**, level: **{conf.get('label', 'N/A')}**). "
        f"Reason: {reason} "
        f"[score breakdown: {why}]"
    )


def _set_followup_notice(level: str, message: str) -> None:
    st.session_state["followup_ack"] = {"level": level, "message": message}


def _report_relation_mismatches(base_report: dict | None, new_report: dict | None) -> list[str]:
    reasons: list[str] = []
    if not base_report or not new_report:
        return reasons
    b_ora = ((base_report.get("ora_code") or {}).get("code") or "").upper()
    n_ora = ((new_report.get("ora_code") or {}).get("code") or "").upper()
    if b_ora and n_ora and b_ora != n_ora:
        reasons.append(f"ORA mismatch: current incident `{b_ora}` vs uploaded bundle `{n_ora}`.")
    b_host = (base_report.get("hostname") or "").lower()
    n_host = (new_report.get("hostname") or "").lower()
    if b_host and n_host and b_host != n_host:
        reasons.append(f"Hostname mismatch: `{base_report.get('hostname')}` vs `{new_report.get('hostname')}`.")
    b_platform = (base_report.get("platform") or "").upper()
    n_platform = (new_report.get("platform") or "").upper()
    if b_platform and n_platform and b_platform != "UNKNOWN" and n_platform != "UNKNOWN" and b_platform != n_platform:
        reasons.append(f"Platform mismatch: `{b_platform}` vs `{n_platform}`.")
    return reasons


# ── Sidebar ───────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("### ⚙️ Query Options")
    override_hostname = st.text_input("Hostname filter", placeholder="dbhost01")
    override_platform = st.selectbox(
        "Platform",
        ["(auto-detect)", "LINUX", "AIX", "SOLARIS", "WINDOWS", "EXADATA", "OCI"]
    )
    override_ora = st.text_input("ORA code override", placeholder="ORA-27072")
    override_ts  = st.text_input("Timestamp", placeholder="2024-03-07T02:44:18")
    top_k        = st.slider("Top K chunks", min_value=3, max_value=20, value=_DEFAULT_TOP_K)

    st.markdown("---")
    st.markdown("### 📊 Index Status")
    try:
        from src.retrieval.bm25_search import index_size
        from src.vectordb.qdrant_client import count_chunks
        st.metric("Qdrant chunks", count_chunks())
        st.metric("BM25 index",    index_size())
    except Exception:
        st.info("Index not yet initialized")

    st.markdown("---")
    try:
        from src.knowledge_graph.pattern_matcher import _compile_patterns
        _n_patterns = len(_compile_patterns())
    except Exception:
        _n_patterns = 0
    st.markdown(
        '<div style="font-size:11px;color:#6e7681;">'
        f'🔒 No LLM · Temperature: 0.0<br>'
        f'{_n_patterns} regex patterns · Model: {_MODEL_NAME}'
        '</div>',
        unsafe_allow_html=True
    )

# ── Main layout ──────────────────────────────────────────────────
st.markdown(
    '<div class="title-bar">'
    '<h1>🔍 Oracle DBA Diagnostic Agent</h1>'
    '<p>Deterministic root-cause analysis · No LLM · Offline-first · Multi-platform</p>'
    '</div>',
    unsafe_allow_html=True
)

_ack = st.session_state.pop("followup_ack", None)

# Session memory for multi-upload incident investigation
if "incident_history" not in st.session_state:
    st.session_state["incident_history"] = []
if "last_report" not in st.session_state:
    st.session_state["last_report"] = None
if "incident_context_text" not in st.session_state:
    st.session_state["incident_context_text"] = ""

# Input tabs
tab_query, tab_file, tab_zip, tab_lab = st.tabs(["📝 Query / Log Paste", "📁 Upload Log File", "🗜️ Upload AHF ZIP", "🔬 PRISM Forensic Lab"])

with tab_query:
    query_input = st.text_area(
        "Enter ORA code, raw log paste, or natural language question",
        height=160,
        placeholder=(
            "Examples:\n"
            "  ORA-27072 on dbhost01\n"
            "  Apr 21 02:44:18 dbhost01 kernel: oracle invoked oom-killer ...\n"
            "  Why does ORA-00257 happen when the archive filesystem is full?"
        ),
    )
    run_btn = st.button("🔍 Diagnose", type="primary", use_container_width=True)

with tab_file:
    uploaded = st.file_uploader(
        "Upload alert.log, /var/log/messages, errpt output, dmesg, iostat...",
        type=["log", "txt", "out", "csv", "trc", "dat", "html", "xml"],
    )
    if uploaded:
        st.success(f"✅ File ready: **{uploaded.name}** ({len(uploaded.getvalue()):,} bytes) — click Diagnose File below.")
    file_btn = st.button("🔍 Diagnose File", type="primary", use_container_width=True)

with tab_zip:
    uploaded_zip = st.file_uploader(
        "Upload AHF ZIP bundle (adrci/ahf/tfactl collection)",
        type=["zip"],
    )
    if uploaded_zip:
        st.success(f"✅ Bundle ready: **{uploaded_zip.name}** ({len(uploaded_zip.getvalue()):,} bytes) — click Analyze Bundle below.")
    zip_btn = st.button("🧠 Analyze Bundle", type="primary", use_container_width=True)

with tab_lab:
    st.markdown("### 🧪 Simulation Sandbox")
    st.markdown('<div style="font-size:12px;color:#8b949e;margin-bottom:10px;">Paste logs from multiple layers to simulate a complex Exadata failure.</div>', unsafe_allow_html=True)
    
    col_l1, col_l2 = st.columns(2)
    with col_l1:
        lab_db_log = st.text_area("Database Alert Log", height=150, placeholder="ORA-15130: diskgroup failure...")
        lab_os_log = st.text_area("OS Syslog / dmesg", height=150, placeholder="InfiniBand link is DOWN")
    with col_l2:
        lab_cell_log = st.text_area("Exadata Cell Alert Log", height=150, placeholder="CELLSRV: Cell Server stopped")
        lab_trace_log = st.text_area("Trace File Snippet", height=150, placeholder="Call Stack: kgh_alloc <- ...")
    
    lab_btn = st.button("🔬 Execute Multi-Log Analysis", type="primary", use_container_width=True)

# ── Run diagnosis ────────────────────────────────────────────────
report = None

platform_val = override_platform if override_platform != "(auto-detect)" else ""

if run_btn and query_input.strip():
    with st.spinner("Running diagnostic pipeline..."):
        try:
            _begin_new_incident_session()
            agent = load_agent()
            report = agent.diagnose(
                query=query_input,
                ora_code=override_ora or "",
                hostname=override_hostname or "",
                timestamp_str=override_ts or "",
                platform=platform_val,
                top_k=top_k,
            )
            st.session_state["last_report"] = report
            st.session_state["incident_context_text"] = query_input.strip()
            _append_incident_history(report)
        except Exception as e:
            st.error(f"Error: {e}")

if lab_btn:
    with st.spinner("Simulating multi-log forensic analysis..."):
        try:
            agent = load_agent()
            report = agent.diagnose_multi(
                logs={
                    "alert": lab_db_log,
                    "syslog": lab_os_log,
                    "cell": lab_cell_log
                },
                hostname=override_hostname or "exadata-lab",
                platform="EXADATA"
            )
            st.session_state["last_report"] = report
            st.session_state["incident_context_text"] += (
                "\n" + "\n".join([lab_db_log or "", lab_os_log or "", lab_cell_log or ""]).strip()
            )
            _append_incident_history(report)
        except Exception as e:
            st.error(f"Lab Simulation Error: {e}")
            st.exception(e)

if file_btn and uploaded:
    import tempfile
    file_bytes = uploaded.getvalue()   # read once before any rerender
    with tempfile.NamedTemporaryFile(mode="wb", suffix=".log", delete=False) as tmp:
        tmp.write(file_bytes)
        tmp_path = tmp.name
    with st.spinner(f"Parsing '{uploaded.name}' and running diagnostic pipeline..."):
        try:
            _begin_new_incident_session()
            agent = load_agent()
            report = agent.diagnose_log_file(
                filepath=tmp_path,
                hostname=override_hostname or "",
                platform=platform_val,
                original_filename=uploaded.name
            )
            st.session_state["last_report"] = report
            st.session_state["incident_context_text"] = (
                file_bytes.decode("utf-8", errors="replace")[:20000]
            )
            _append_incident_history(report)
        except Exception as e:
            st.error(f"Error: {e}")
            st.exception(e)
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass
elif file_btn and not uploaded:
    st.warning("⚠️ Please upload a log file first, then click Diagnose File.")

if zip_btn and uploaded_zip:
    import tempfile
    zip_bytes = uploaded_zip.getvalue()
    with tempfile.NamedTemporaryFile(mode="wb", suffix=".zip", delete=False) as tmp:
        tmp.write(zip_bytes)
        zip_path = tmp.name
    with st.spinner(f"Extracting and analyzing bundle '{uploaded_zip.name}'..."):
        try:
            _begin_new_incident_session()
            agent = load_agent()
            report = agent.diagnose_ahf_zip(
                zip_path=zip_path,
                hostname=override_hostname or "",
                platform=platform_val,
            )
            st.session_state["last_report"] = report
            _append_zip_bundle_to_incident_context("ZIP_UPLOAD", uploaded_zip.name, report)
            _append_incident_history(report)
        except Exception as e:
            st.error(f"Bundle analysis error: {e}")
            st.exception(e)
        finally:
            try:
                os.unlink(zip_path)
            except OSError:
                pass
elif zip_btn and not uploaded_zip:
    st.warning("⚠️ Please upload a ZIP bundle first, then click Analyze Bundle.")

# ── Render report ─────────────────────────────────────────────────
if report is None:
    report = st.session_state.get("last_report")

if report:
    if _ack:
        if isinstance(_ack, dict):
            level = _ack.get("level", "success")
            msg = _ack.get("message", "")
        else:
            level = "success"
            msg = str(_ack)
        if msg:
            if level == "warning":
                st.warning(msg)
            elif level == "error":
                st.error(msg)
            else:
                st.success(msg)

    status = report.get("status", "NO_MATCH")
    conf   = report.get("confidence", {})
    score  = conf.get("score", 0)
    label  = conf.get("label", "NO_MATCH")
    bd     = conf.get("breakdown", {})

    # ── Top metrics row ──────────────────────────────────────────
    st.markdown(
        f'<div class="metric-row">'
        f'<div class="metric-box"><div class="metric-val">{_badge(label)}</div>'
        f'<div class="metric-lbl">Confidence Level</div></div>'
        f'<div class="metric-box"><div class="metric-val" style="color:#58a6ff">{score}%</div>'
        f'<div class="metric-lbl">Confidence Score</div></div>'
        f'<div class="metric-box"><div class="metric-val" style="color:#8b949e">'
        f'{report.get("platform","")}</div><div class="metric-lbl">Platform</div></div>'
        f'<div class="metric-box"><div class="metric-val" style="color:#8b949e">'
        f'{report.get("processing_ms",0):.0f}ms</div><div class="metric-lbl">Processing Time</div></div>'
        f'</div>',
        unsafe_allow_html=True
    )

    if status == "NO_MATCH":
        ora = report.get("ora_code", {}) or {}
        if ora.get("code"):
            st.markdown(
                f'<div class="card"><div class="card-title">Known ORA Context</div>'
                f'<div style="font-size:20px;font-weight:700;color:#f2cc60">{ora.get("code")}'
                f' <span style="font-size:12px;color:#8b949e">({ora.get("layer","UNKNOWN")})</span></div>'
                f'<div style="margin-top:6px;color:#c9d1d9">{ora.get("description","")}</div></div>',
                unsafe_allow_html=True
            )
            st.info(
                "This is the general meaning of the ORA code. "
                "Incident root cause is still unconfirmed until correlated DB + OS/infra evidence is provided."
            )
            pfixes = report.get("fixes", []) or []
            if pfixes and pfixes[0].get("commands"):
                with st.expander("📘 Provisional Runbook Guidance (requires more evidence)", expanded=True):
                    first = pfixes[0]
                    for cmd in first.get("commands", []):
                        st.markdown(f"- {cmd}")

        reason = report.get("no_match_reason", "No matching pattern found.")
        raw_in = (report.get("query") or query_input or "").lower()
        if any(x in raw_in for x in ["none found", "health check passed", "completed successfully"]):
            reason = "This looks like an informational health-check log, not an active incident."
        st.warning(f"⚠️ {reason}")
        follow_up = report.get("follow_up_question") or (
            "I could not map this to a known Oracle DB/OS incident pattern. "
            "Please upload related Oracle and host logs from the same window "
            "(alert.log, /var/log/messages, trace, CRS/OSWatcher) so I can correlate."
        )
        st.info(follow_up)
        missing = report.get("missing_evidence") or []
        if missing:
            with st.expander("🧩 Why This Is Not Final Yet", expanded=True):
                st.markdown(
                    "Confidence is below final threshold or evidence is generic. "
                    "Please provide:"
                )
                for item in missing:
                    st.markdown(f"- {item}")

        st.markdown("### ➕ Continue Investigation")
        st.markdown(
            '<div style="font-size:12px;color:#8b949e;margin-bottom:8px;">'
            'Add more evidence right here (paste, single file, or ZIP) and run another pass.'
            '</div>',
            unsafe_allow_html=True
        )

        # Form wraps paste + submit so the latest pasted text is always sent with the
        # button action (avoids Streamlit race where a plain button can fire before the
        # text_area value is committed on the same run).
        with st.form("followup_paste_form", clear_on_submit=False):
            fu_text = st.text_area(
                "Paste related logs",
                height=120,
                placeholder="Paste alert.log/messages/trace snippets from the same incident window...",
                key="followup_text_input",
            )
            form_paste_submit = st.form_submit_button(
                "Diagnose Pasted Follow-up",
                use_container_width=True,
                type="primary",
            )

        st.markdown(
            '<div style="font-size:12px;color:#8b949e;margin:8px 0 4px 0;">'
            "Or upload a log or AHF ZIP below, then use the matching button.</div>",
            unsafe_allow_html=True,
        )

        col_fu1, col_fu2 = st.columns(2)
        with col_fu1:
            fu_file = st.file_uploader(
                "Upload related log file",
                type=["log", "txt", "out", "csv", "trc", "dat", "html", "xml"],
                accept_multiple_files=True,
                key="followup_file_upload",
            )
        with col_fu2:
            fu_zip = st.file_uploader(
                "Upload related AHF ZIP",
                type=["zip"],
                key="followup_zip_upload",
            )

        col_act2, col_act3 = st.columns(2)

        if form_paste_submit:
            if fu_text.strip():
                with st.spinner("Running follow-up diagnosis from pasted evidence..."):
                    try:
                        is_related, reasons = _evaluate_followup_relevance(
                            fu_text,
                            st.session_state.get("last_report"),
                            override_hostname or "",
                            override_platform,
                        )
                        if not is_related:
                            _set_followup_notice(
                                "warning",
                                "Follow-up rejected as unrelated to the active incident.\n\n- "
                                + "\n- ".join(reasons)
                            )
                            st.rerun()
                        else:
                            agent = load_agent()
                            combined_text = (
                                (st.session_state.get("incident_context_text", "") + "\n" + fu_text).strip()
                            )
                            report = agent.diagnose(
                                query=combined_text,
                                ora_code=override_ora or "",
                                hostname=override_hostname or "",
                                timestamp_str=override_ts or "",
                                platform=platform_val,
                                top_k=top_k,
                            )
                            st.session_state["last_report"] = report
                            st.session_state["incident_context_text"] = combined_text
                            st.session_state["followup_ack"] = _followup_ack(
                                report,
                                "Follow-up diagnosis finished"
                            )
                            _append_incident_history(report)
                            st.rerun()
                    except Exception as e:
                        st.error(f"Follow-up analysis error: {e}")
            else:
                st.warning("Please paste related logs first.")

        if col_act2.button("Diagnose Follow-up File", use_container_width=True, key="fu_btn_file"):
            selected_files = []
            if isinstance(fu_file, list):
                selected_files = [f for f in fu_file if f is not None]
            elif fu_file is not None:
                selected_files = [fu_file]

            if selected_files:
                with st.spinner(f"Analyzing {len(selected_files)} follow-up file(s)..."):
                    try:
                        agent = load_agent()
                        rendered_parts = []
                        for fobj in selected_files:
                            try:
                                chunk = fobj.getvalue().decode("utf-8", errors="replace")
                            except Exception:
                                chunk = ""
                            rendered_parts.append(f"\n# file={fobj.name}\n{chunk}")
                        file_text = "\n".join(rendered_parts).strip()
                        is_related, reasons = _evaluate_followup_relevance(
                            file_text,
                            st.session_state.get("last_report"),
                            override_hostname or "",
                            override_platform,
                        )
                        if not is_related:
                            _set_followup_notice(
                                "warning",
                                "Follow-up file(s) rejected as unrelated to active incident.\n\n- "
                                + "\n- ".join(reasons)
                            )
                            st.rerun()
                        else:
                            combined_text = (
                                (st.session_state.get("incident_context_text", "") + "\n" + file_text).strip()
                            )
                            report = agent.diagnose(
                                query=combined_text,
                                ora_code=override_ora or "",
                                hostname=override_hostname or "",
                                timestamp_str=override_ts or "",
                                platform=platform_val,
                                top_k=top_k,
                            )
                            st.session_state["last_report"] = report
                            st.session_state["incident_context_text"] = combined_text
                            st.session_state["followup_ack"] = _followup_ack(
                                report,
                                f"Follow-up file analysis finished ({len(selected_files)} file(s))"
                            )
                            _append_incident_history(report)
                            st.rerun()
                    except Exception as e:
                        st.error(f"Follow-up file analysis error: {e}")
            else:
                st.warning("Please upload a follow-up file first.")

        if col_act3.button("Diagnose Follow-up ZIP", use_container_width=True, key="fu_btn_zip"):
            if fu_zip is not None:
                import tempfile
                zip_bytes = fu_zip.getvalue()
                with tempfile.NamedTemporaryFile(mode="wb", suffix=".zip", delete=False) as tmp_in:
                    tmp_in.write(zip_bytes)
                    input_zip_path = tmp_in.name
                with tempfile.NamedTemporaryFile(mode="wb", suffix=".zip", delete=False) as tmp_out:
                    zip_path = tmp_out.name
                # Merge existing incident context into the uploaded bundle so
                # follow-up ZIP analysis can correlate with earlier evidence.
                with zipfile.ZipFile(input_zip_path, "r") as zin, zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zout:
                    for info in zin.infolist():
                        zout.writestr(info, zin.read(info.filename))
                    context_text = st.session_state.get("incident_context_text", "").strip()
                    if context_text:
                        zout.writestr("followup/context_from_previous_steps.log", context_text)
                with st.spinner(f"Analyzing follow-up ZIP '{fu_zip.name}'..."):
                    try:
                        agent = load_agent()
                        prev_report = st.session_state.get("last_report")
                        report = agent.diagnose_ahf_zip(
                            zip_path=zip_path,
                            hostname=override_hostname or "",
                            platform=platform_val,
                        )
                        mismatches = _report_relation_mismatches(prev_report, report)
                        if mismatches:
                            _set_followup_notice(
                                "warning",
                                "Follow-up ZIP rejected as different incident context.\n\n- "
                                + "\n- ".join(mismatches)
                            )
                            st.rerun()
                        else:
                            st.session_state["last_report"] = report
                            _append_zip_bundle_to_incident_context("ZIP_FOLLOWUP", fu_zip.name, report)
                            st.session_state["followup_ack"] = _followup_ack(
                                report,
                                "Follow-up ZIP analysis finished"
                            )
                            _append_incident_history(report)
                            st.rerun()
                    except Exception as e:
                        st.error(f"Follow-up ZIP analysis error: {e}")
                    finally:
                        try:
                            os.unlink(zip_path)
                        except OSError:
                            pass
                        try:
                            os.unlink(input_zip_path)
                        except OSError:
                            pass
            else:
                st.warning("Please upload a follow-up ZIP first.")
    elif status == "PROVISIONAL":
        st.info(
            "Provisional bundle-level decision: strong parser evidence was found, "
            "but final RCA confirmation is pending additional validation."
        )
    else:
        # Layout: 2 columns
        col1, col2 = st.columns([3, 2])

        with col1:
            # ORA Code
            ora = report.get("ora_code", {})
            if ora.get("code"):
                st.markdown(
                    f'<div class="card"><div class="card-title">ORA Code</div>'
                    f'<b style="color:#f0883e;font-size:16px">{ora["code"]}</b>'
                    f'<span style="color:#8b949e;font-size:12px"> [{ora.get("layer","")}]</span><br>'
                    f'<span style="font-size:13px">{ora.get("description","")}</span></div>',
                    unsafe_allow_html=True
                )

            # Guided Diagnostic Solicitation
            solicit = report.get("solicitation", [])
            if solicit:
                st.markdown(
                    f'<div class="card" style="border: 1px solid #f0883e; background: rgba(240, 136, 62, 0.05);">'
                    f'<div style="color:#f0883e; font-weight:bold; margin-bottom:8px; font-size:14px;">🧠 Guided Diagnostic</div>'
                    f'<div style="font-size:12px; color:#c9d1d9; margin-bottom:10px;">I\'ve detected a potential <b>{report.get("root_cause",{}).get("category","")}</b> layer issue. To confirm the root cause, please upload:</div>',
                    unsafe_allow_html=True
                )
                for s in solicit:
                    st.markdown(f'<div style="font-size:12px; color:#8b949e; margin-left:12px;">• <code>{s}</code></div>', unsafe_allow_html=True)
                st.markdown('</div>', unsafe_allow_html=True)

            # Root Cause
            rc = report.get("root_cause", {})
            if rc:
                st.markdown(
                    f'<div class="card"><div class="card-title">Root Cause</div>'
                    f'<b style="color:#da3633;font-size:15px">{rc.get("pattern","")}</b>'
                    f'<span style="color:#8b949e;font-size:12px"> [{rc.get("category","")} · {rc.get("severity","")}]</span><br>'
                    + (f'<span style="color:#79c0ff;font-size:12px">Device: {rc["device"]}</span><br>' if rc.get("device") else "")
                    + f'<span style="font-size:13px">{rc.get("description","")}</span></div>',
                    unsafe_allow_html=True
                )

            # Trace Deep Dive (Phase B)
            analysis = report.get("trace_analysis")
            if analysis:
                pinfo = analysis.get("process_info", {})
                pinfo_str = " · ".join([f"<b>{k}:</b> {v}" for k, v in pinfo.items()])
                stack = analysis.get("call_stack", [])
                
                st.markdown(
                    f'<div class="card" style="border-left:3px solid #79c0ff;">'
                    f'<div class="card-title">🔬 Trace Deep Dive</div>'
                    f'<div style="font-size:12px;margin-bottom:8px;color:#c9d1d9">{pinfo_str}</div>'
                    f'</div>',
                    unsafe_allow_html=True
                )
                if stack:
                    with st.expander("View Call Stack Frames", expanded=True):
                        st.code("\n".join(stack), language="text")

            # Security Correlation (Phase C)
            sec_insights = report.get("security_insights", [])
            if sec_insights:
                st.markdown(
                    f'<div class="card" style="border-left:3px solid #bc8cff;">'
                    f'<div class="card-title">🔒 Security Correlation</div>',
                    unsafe_allow_html=True
                )
                for insight in sec_insights[:3]:
                    color = "#da3633" if insight["severity"] in ("CRITICAL", "ERROR") else "#f0883e"
                    st.markdown(
                        f'<div style="font-size:12px;margin-bottom:4px">'
                        f'<span style="color:{color};font-weight:bold">[{insight["event"]}]</span> '
                        f'<span style="color:#8b949e">{insight["text"]}</span></div>',
                        unsafe_allow_html=True
                    )
                st.markdown('</div>', unsafe_allow_html=True)

            # Exadata Hardware Health (Phase E)
            hw_health = report.get("hardware_health", [])
            if hw_health:
                st.markdown(
                    f'<div class="card" style="border-left:3px solid #39d353;">'
                    f'<div class="card-title">🛡️ Exadata Hardware Health</div>',
                    unsafe_allow_html=True
                )
                for item in hw_health[:3]:
                    color = "#da3633" if item["severity"] in ("CRITICAL", "ERROR") else "#39d353"
                    st.markdown(
                        f'<div style="font-size:12px;margin-bottom:4px">'
                        f'<span style="color:{color};font-weight:bold">[{item["event"]}]</span> '
                        f'<span style="color:#8b949e">{item["text"]}</span></div>',
                        unsafe_allow_html=True
                    )
                st.markdown('</div>', unsafe_allow_html=True)

            # Causal chain
            chain = report.get("causal_chain", [])
            if chain:
                st.markdown('<div class="card"><div class="card-title">Causal Chain</div>', unsafe_allow_html=True)
                _render_causal_chain(chain)
                st.markdown('</div>', unsafe_allow_html=True)

            rca = report.get("rca_framework")
            if rca:
                with st.expander("📐 Evidence-first RCA (roles, cascade, correlation)", expanded=False):
                    st.markdown(f"**Executive summary:** {rca.get('executive_summary', '')}")
                    rc = rca.get("root_cause_candidate") or {}
                    if rc:
                        st.markdown(
                            f"**Root candidate:** `{rc.get('root_cause','')}` · "
                            f"layer **{rc.get('layer','')}** · evidence status **{rc.get('status','')}** · "
                            f"RCA correlation score **{rc.get('correlation_score','')}**"
                        )
                        st.caption(rc.get("why_deepest_supported", ""))
                    cmarked = rca.get("cascade_chain_marked") or []
                    if cmarked:
                        st.markdown("**Cascade (marked):**")
                        st.code("\n".join(f"  → {s}" for s in cmarked), language="text")
                    ora_tbl = rca.get("observed_ora_correlation_table") or rca.get("correlated_error_table") or []
                    if ora_tbl:
                        st.markdown("**Observed ORA codes (not LGWR / not patterns):**")
                        st.table(
                            [
                                {
                                    "ORA": r.get("error", ""),
                                    "Role": r.get("role", ""),
                                    "Layer": r.get("layer", ""),
                                    "Meaning": (r.get("meaning", "") or "")[:120],
                                }
                                for r in ora_tbl
                            ]
                        )
                    non_ora = rca.get("non_ora_correlated_events") or []
                    if non_ora:
                        st.markdown("**Non-ORA correlated events / patterns:**")
                        st.caption("These rows are not ORA codes (e.g. LGWR termination, storage signals, regex patterns).")
                        st.table(
                            [
                                {
                                    "Event": r.get("event", ""),
                                    "Role": r.get("role", ""),
                                    "Layer": r.get("layer", ""),
                                    "Meaning": (r.get("meaning", "") or "")[:120],
                                }
                                for r in non_ora
                            ]
                        )
                    evtl = rca.get("evidence_timeline") or []
                    if evtl:
                        st.markdown("**Evidence timeline (extracted):**")
                        st.dataframe(evtl[:25], use_container_width=True, hide_index=True)
                    st.markdown(f"**Correlation confidence note:** {rca.get('confidence_explanation', '')}")
                    rd = rca.get("remediation_direction") or {}
                    if rd:
                        st.markdown("**Remediation direction (by layer):**")
                        for k, v in rd.items():
                            st.markdown(f"- **{k}:** {v}")
                    need = rca.get("additional_evidence_needed") or []
                    if need:
                        st.markdown("**Additional evidence:**")
                        for n in need:
                            st.markdown(f"- {n}")

            # Cascade
            cascade = report.get("cascade")
            if cascade:
                st.markdown(
                    f'<div class="cascade-banner">'
                    f'⚡ <b>CASCADE DETECTED</b> — {cascade["note"]}<br>'
                    f'<span style="font-size:12px;color:#8b949e">Sequence: '
                    + " → ".join(f"<code>{s}</code>" for s in cascade.get("sequence",[]))
                    + f'&nbsp;&nbsp;Match: {cascade["match_pct"]}%</span></div>',
                    unsafe_allow_html=True
                )

        with col2:
            # Score breakdown
            st.markdown('<div class="card"><div class="card-title">Score Breakdown</div>', unsafe_allow_html=True)
            conf = report.get("confidence") or {}
            if conf.get("correlation_model_score") is not None:
                st.caption(
                    f"RCA correlation model: **{conf.get('correlation_model_score')}** · "
                    f"Evidence status: **{conf.get('root_cause_evidence_status', 'N/A')}** "
                    f"(separate from retrieval fusion below)."
                )
            if conf.get("retrieval_note"):
                st.caption(conf["retrieval_note"])
            for component, val in bd.items():
                weight_lbl = {"keyword":"Keyword (40%)","bm25":"BM25 (30%)","dense":"Semantic (20%)","temporal":"Temporal (10%)"}.get(component, component)
                st.progress(int(val) if val <= 40 else 40, text=f"{weight_lbl}: {val}")
            st.markdown("</div>", unsafe_allow_html=True)

            # Related errors
            related = report.get("related_errors", [])
            if related:
                st.markdown(
                    '<div class="card"><div class="card-title">Related ORA Codes</div>'
                    + " ".join(f'<code style="background:#21262d;padding:2px 6px;border-radius:4px">{r}</code>' for r in related)
                    + "</div>",
                    unsafe_allow_html=True
                )

            # Hostname/Platform
            st.markdown(
                f'<div class="card"><div class="card-title">Context</div>'
                f'Host: <b>{report.get("hostname","unknown")}</b><br>'
                f'Platform: <b>{report.get("platform","")}</b><br>'
                f'Query mode: <b>{report.get("query_mode","")}</b></div>',
                unsafe_allow_html=True
            )

        # ── Fixes ────────────────────────────────────────────────
        fixes = report.get("fixes", [])
        if fixes:
            st.markdown("### 🔧 Remediation commands")
            st.caption("Prefer diagnostics and layered direction until root is confirmed. Check [command_category] on each bundle.")
            for i, fix in enumerate(fixes):
                _render_fix(fix, i)

        # ── Diagnostics ──────────────────────────────────────────
        diags = report.get("diagnostics", [])
        if diags:
            with st.expander("🔎 Diagnostic Commands (run to confirm)", expanded=False):
                for cmd in diags:
                    st.code(cmd, language="bash")

        # ── Phase D: Incident Package ────────────────────────────
        pkg = report.get("package_info")
        if pkg:
            st.markdown("---")
            col_p1, col_p2 = st.columns([0.7, 0.3])
            with col_p1:
                st.markdown(
                    f"### 📦 Incident Evidence Package\n"
                    f"A diagnostic bundle containing trace files and automated findings has been generated.\n\n"
                    f"**File:** `{pkg['filename']}` ({pkg['size_mb']} MB)"
                )
            with col_p2:
                try:
                    with open(pkg["path"], "rb") as f:
                        st.download_button(
                            label="Download ZIP",
                            data=f,
                            file_name=pkg["filename"],
                            mime="application/zip",
                            use_container_width=True
                        )
                except Exception as e:
                    st.error(f"Failed to read package: {e}")

        # ── Evidence ─────────────────────────────────────────────
        evidence = report.get("evidence", [])
        if evidence:
            with st.expander(f"📄 Evidence ({len(evidence)} chunks)", expanded=False):
                for ev in evidence:
                    st.markdown(
                        f'<div class="card" style="margin-bottom:8px">'
                        f'<b style="color:#58a6ff">{ev.get("log_source","")}</b>'
                        f'&nbsp;·&nbsp;{ev.get("timestamp","")}'
                        f'&nbsp;·&nbsp;<span style="color:#8b949e">{ev.get("hostname","")}</span>'
                        f'&nbsp;·&nbsp;score={ev.get("rrf_score",0)}<br>'
                        f'<div class="evidence-box">{ev.get("raw_text","")}</div></div>',
                        unsafe_allow_html=True
                    )

        # ── JSON view ────────────────────────────────────────────
        with st.expander("🗂 Raw JSON Report", expanded=False):
            st.json(report)

    bundle = report.get("bundle_summary")
    if bundle:
        st.markdown("---")
        st.markdown(
            f"**Bundle analysis:** {bundle.get('analyzed_files', 0)} files scanned"
            + (f" · primary: `{bundle.get('primary_file')}`" if bundle.get("primary_file") else "")
            + (f" · platform: `{bundle.get('platform_inferred')}`" if bundle.get("platform_inferred") else "")
        )
        extra_parts = []
        if bundle.get("total_extracted_files") is not None:
            extra_parts.append(f"extracted: **{bundle.get('total_extracted_files')}**")
        if bundle.get("candidate_files_found") is not None:
            extra_parts.append(f"candidate logs: **{bundle.get('candidate_files_found')}**")
        if bundle.get("max_files_cap") is not None:
            extra_parts.append(f"cap: **{bundle.get('max_files_cap')}**")
        if extra_parts:
            st.caption(" · ".join(extra_parts))
        state_counts = bundle.get("file_state_counts") or {}
        if state_counts:
            st.markdown(
                f"**File states:** MATCH `{state_counts.get('MATCH', 0)}` · "
                f"SIGNAL_ONLY `{state_counts.get('SIGNAL_ONLY', 0)}` · "
                f"NO_MATCH `{state_counts.get('NO_MATCH', 0)}`"
            )

    zip_diags = report.get("zip_ingest_diagnostics") or {}
    zip_events = report.get("zip_normalized_events") or []
    if zip_diags or zip_events:
        parsed_files = zip_diags.get("parsed_files") or []
        skipped_extract = zip_diags.get("skipped_from_extract") or []
        skipped_runtime = zip_diags.get("skipped") or []
        st.markdown(
            f"**ZIP coverage:** parsed `{len(parsed_files)}` files · "
            f"skipped at extract `{len(skipped_extract)}` · skipped at parse `{len(skipped_runtime)}` · "
            f"normalized events `{len(zip_events)}`"
        )
        if skipped_extract or skipped_runtime:
            with st.expander("⚠️ Skipped Files and Reasons", expanded=False):
                if skipped_extract:
                    st.markdown("**Skipped during extract**")
                    st.json(skipped_extract[:50])
                if skipped_runtime:
                    st.markdown("**Skipped during parse**")
                    st.json(skipped_runtime[:50])
        if zip_events:
            layers = Counter((e.get("layer") or "UNKNOWN") for e in zip_events)
            top_codes = Counter((e.get("code") or "NA") for e in zip_events).most_common(12)
            with st.expander("🧾 ZIP Evidence Summary", expanded=False):
                st.markdown(f"**Layers:** `{dict(layers)}`")
                st.markdown(f"**Top codes:** `{top_codes}`")
    secondary = report.get("secondary_findings", [])
    if secondary:
        with st.expander("📚 Other Findings From Bundle", expanded=False):
            match_rows = [r for r in secondary if r.get("match_state") == "MATCH"]
            signal_rows = [r for r in secondary if r.get("match_state") == "SIGNAL_ONLY"]
            no_rows = [r for r in secondary if r.get("match_state") == "NO_MATCH"]
            st.markdown(
                f"**Rows shown:** `{len(secondary)}` · MATCH `{len(match_rows)}` · "
                f"SIGNAL_ONLY `{len(signal_rows)}` · NO_MATCH `{len(no_rows)}`"
            )
            kb_hits_total = sum(int(r.get("kb_hit_count") or 0) for r in secondary)
            kb_ora_total = sum(len(r.get("kb_ora_hits") or []) for r in secondary)
            st.caption(
                f"KB hits across shown rows: {kb_hits_total} "
                f"(including PDF/graph ORA hits: {kb_ora_total})"
            )
            st.json(secondary)

    prism = report.get("prism")
    if prism:
        with st.expander("🧭 PRISM Incident View", expanded=True):
            st.markdown(f"**Signal:** {prism.get('signal', 'N/A')}")
            st.markdown(f"**Correlation:** {prism.get('correlation', 'N/A')}")
            st.markdown(f"**Root Cause:** {prism.get('root_cause', 'N/A')}")
            st.markdown(f"**Action Plan:** {prism.get('action_plan', 'N/A')}")
            st.markdown(f"**Confidence:** {prism.get('confidence', 'N/A')}")

    llm_adv = report.get("llm_advisory") or {}
    if llm_adv:
        with st.expander("🤖 LLM Advisory (Constrained)", expanded=False):
            st.markdown(f"**Used:** `{llm_adv.get('used', False)}` · **Mode:** `{llm_adv.get('mode', 'off')}`")
            if llm_adv.get("model"):
                st.markdown(f"**Model:** `{llm_adv.get('model')}`")
            if llm_adv.get("reason"):
                st.caption(f"Reason: {llm_adv.get('reason')}")
            if llm_adv.get("selected_hypothesis"):
                st.markdown(f"**Selected hypothesis:** `{llm_adv.get('selected_hypothesis')}`")
            if llm_adv.get("confidence_band"):
                st.markdown(f"**Confidence band:** `{llm_adv.get('confidence_band')}`")
            if llm_adv.get("rationale"):
                st.markdown(f"**Rationale:** {llm_adv.get('rationale')}")
            if "policy_passed" in llm_adv:
                st.markdown(f"**Policy passed:** `{llm_adv.get('policy_passed')}`")
            if llm_adv.get("violations"):
                st.warning(f"Policy violations: {llm_adv.get('violations')}")
            next_cmds = llm_adv.get("next_commands") or []
            if next_cmds:
                st.markdown("**Suggested next commands (advisory):**")
                for cmd in next_cmds:
                    st.code(cmd, language="bash")
            need_more = llm_adv.get("needs_more_evidence") or []
            if need_more:
                st.markdown("**Suggested additional evidence:**")
                for item in need_more:
                    st.markdown(f"- {item}")

    if st.session_state["incident_history"]:
        with st.expander("🗂 Incident Session Memory", expanded=False):
            st.json(st.session_state["incident_history"][-10:])
